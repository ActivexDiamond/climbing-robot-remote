#!/bin/bash
#Development-only bash script for running some tests. Useful for testing hardware configurations. Mac-version.
/Applications/love.app/Contents/MacOS/love tests/src