local class = require "libs.middleclass"

--[[
	Check PeripheralApi for a description of what the hell this is.
	
	Should this handle network init and such? Stick that in the PeripheralApi? Have a dedicated one? Up to you.
--]]
------------------------------ Constructor ------------------------------
local PiApi = class("PiApi")
function PiApi:initialize()
end

------------------------------ API ------------------------------


------------------------------ Getters / Setters ------------------------------

return PiApi()
