#!/bin/bash
#Development-only bash script for running some tests. Useful for testing hardware configurations.
sudo love tests/src