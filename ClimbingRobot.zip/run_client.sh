#!/bin/bash
#Runs the client program (the remote's code). For the Pi.
love /home/pi/cr/remote/src