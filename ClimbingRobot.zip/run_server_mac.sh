#!/bin/bash
#Runs the server program (the robot's code). For macOS.
/Applications/love.app/Contents/MacOS/love robot/src