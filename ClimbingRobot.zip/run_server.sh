#!/bin/bash
#Runs the server program (the robot's code). For the Pi.
sudo love /home/pi/cr/robot/src