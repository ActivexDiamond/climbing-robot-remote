#!/bin/bash
#Runs the client program (the remote's code).
/Applications/love.app/Contents/MacOS/love remote/src